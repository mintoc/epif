### Name: coxph.disparity.R
### Title: Check disparity in a Cox Proportional Hazard Model
### Aliases: coxph.disparity
### Keywords: survival

### ** Examples

require('SMIR')
require('survival')
data(feigl)
feigl <- within(feigl, {lwbc <- log(wbc)})
feigl.cph <- coxph(Surv(time) ~ ag * lwbc, data = feigl,
                   method = "breslow")
coxph.disparity(feigl.cph)



