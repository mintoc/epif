### Name: RsqCV
### Title: Cross-validated coefficient of determination
### Aliases: RsqCV R2CV rsqcv
### Keywords: regression

### ** Examples

data(trees,package="SMIR")
RsqCV(lm(v~h+d,data=trees))



