### Name: lsat
### Title: LSAT
### Aliases: lsat
### Keywords: datasets

### ** Examples

data(lsat)
## maybe str(lsat) ; plot(lsat) ...



