### Name: summary.treg
### Title: Summarizing t-regression model fits
### Aliases: summary.treg summary
### Keywords: robust

### ** Examples

library(SMIR)
data(stackloss)
stackloss.lm <- lm(y ~ x1 + x2 + x3, data = stackloss)
(stackloss.treg1.1 <- treg(stackloss.lm , r=1.1, verbose = FALSE) )
summary(stackloss.treg1.1)



