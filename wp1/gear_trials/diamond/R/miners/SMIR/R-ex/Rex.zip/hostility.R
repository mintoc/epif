### Name: hostility
### Title: Bennett's hostility data
### Aliases: hostility
### Keywords: datasets

### ** Examples

data(hostility)
## maybe str(hostility)
plot(hostility)



