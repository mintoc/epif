### Name: toxaemia
### Title: Bradford toxaemia data
### Aliases: toxaemia
### Keywords: datasets

### ** Examples

data(toxaemia, package = "SMIR")
tox.prop.table1 <- with(toxaemia, prop.table(tapply(count,
 list(class = class, response = response, smoke = smoke),
 sum), c(1, 3))[, c(2, 1, 4, 3), 1:2])
tox.prop.table2 <- with(toxaemia, prop.table(tapply(count,
 list(class = class, response = response, smoke = smoke),
 sum), c(1, 3))[, c(2, 1, 4, 3), 3, drop = FALSE])



