### Name: woolson
### Title: Woolson and Clarke's Obesity Study
### Aliases: woolson
### Keywords: datasets

### ** Examples

data(woolson)



